/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.vtt.service;

import com.vtt.pojo.Category;
import java.util.List;

/**
 *
 * @author vutrongthang
 */
public interface CategoryService {
    List<Category> getCategories();
    
}
